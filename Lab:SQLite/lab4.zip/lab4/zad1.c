#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <sys/time.h>

#define MAX_NAME_LENGTH 20
#define MAX_DESC_LENGTH 90
#define NUM_RECORDS 1000000
#define TARGET_ID 999999

struct Record {
    int id;            
    char name[MAX_NAME_LENGTH];
    char desc[MAX_DESC_LENGTH];
};

struct Record *create_record(int id, const char *name, const char *desc) {
    struct Record *record = (struct Record *)malloc(sizeof(struct Record));
    if (record != NULL) {
        record->id = id;
        strncpy(record->name, name, MAX_NAME_LENGTH - 1);
        record->name[MAX_NAME_LENGTH - 1] = '\0'; 
        strncpy(record->desc, desc, MAX_DESC_LENGTH - 1);
        record->desc[MAX_DESC_LENGTH - 1] = '\0';
    }
    return record;
}

void free_records(struct Record **records, int num_records) {
    for (int i = 0; i < num_records; ++i) {
        free(records[i]);
    }
    free(records);
}

int main() {

    struct timeval start_generation, end_generation;
    gettimeofday(&start_generation, NULL);

    struct Record **records = (struct Record **)malloc(NUM_RECORDS * sizeof(struct Record *));
    if (records == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        return 1;
    }

    for (int i = 0; i < NUM_RECORDS; ++i) {
        char name[MAX_NAME_LENGTH];
        char desc[MAX_DESC_LENGTH];
        sprintf(name, "Name_%d", i);
        sprintf(desc, "Description_%d", i);
        records[i] = create_record(i, name, desc);
        if (records[i] == NULL) {
            fprintf(stderr, "Memory allocation failed\n");
            free_records(records, i);
            return 1;
        }
    }


    gettimeofday(&end_generation, NULL);
    long generation_time = (end_generation.tv_sec - start_generation.tv_sec) * 1000000L + (end_generation.tv_usec - start_generation.tv_usec);


    struct timeval start_search, end_search;
    gettimeofday(&start_search, NULL);

    int found = 0;
    for (int i = 0; i < NUM_RECORDS; ++i) {
        if (records[i]->id == TARGET_ID) {
            printf("Record found with id %d:\n", TARGET_ID);
            printf("Name: %s\n", records[i]->name);
            printf("Description: %s\n", records[i]->desc);
            found = 1;
            break;
        }
    }
    if (!found) {
        printf("Record with id %d not found.\n", TARGET_ID);
    }

    gettimeofday(&end_search, NULL);
    long search_time = (end_search.tv_sec - start_search.tv_sec) * 1000000L + (end_search.tv_usec - start_search.tv_usec);


    free_records(records, NUM_RECORDS);

    struct rusage usage;
    getrusage(RUSAGE_SELF, &usage);
    long memory_usage = usage.ru_maxrss;

    printf("\nMemory usage: %ld KB\n", memory_usage);
    printf("Time needed to generate records: %ld microseconds\n", generation_time);
    printf("Time taken to search for a record: %ld microseconds\n", search_time);

    return 0;
}
